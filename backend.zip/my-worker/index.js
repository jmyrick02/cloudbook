const headers = {
  'Access-Control-Allow-Origin': '*',
}

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})
/**
 * Respond with hello worker text
 * @param {Request} request
 */
async function handleRequest(request) {
  if (request.url.split("/").at(-1) === "posts") {
    if (request.method === "GET") {
      let keys = (await MY_KV.list()).keys
      posts = []
      for (const key of keys) {
        posts.push(await MY_KV.get(key.name))
      }
      return new Response(JSON.stringify(posts), { headers, 'Content-type': 'application/json' })
    } else if (request.method === "POST") {
      try {
        var obj = await request.json();
        if (!obj.uuid) {
          obj.uuid = crypto.randomUUID();
        }
      } catch (error) {
        return new Response("error: invalid json", { headers });
      }
      await MY_KV.put(obj.uuid, JSON.stringify(obj))
      return new Response("success", { headers })
    }
  }

  return new Response("error: not found", { headers })
}
